<footer class="main-footer">
    <!-- <div class="pull-right hidden-xs">
      <b>Version</b> 2.3.0
    </div>
    <div>Copyright &copy; 2018 <a href="#">R K H</a>.</div> All rights reserved. -->
    <p>
      <b>kostNING</b> "Tempat Kost Mbok Ning", kost putra yang bertempat di jln. Kembang kertas No. 24. Area aman dan juga murah
    </p>
    <p>
      <div class="row">
        <div class="col-xs-4">contact us: </div>
        <div class="col-xs-8 text-right"><p class="fa fa-whatsapp">0812-5219-4102</p></div>
        <div class="col-xs-12 text-right"><p class="fa fa-envelope">kostning@gmail.com</p></div>
      </div>
    </p>
</footer>

    <!-- jQuery 2.1.4 -->
    <!-- <script src="../aset/plugins/jQuery/jQuery-2.1.4.min.js"></script> -->
    <!-- Bootstrap 3.3.5 -->
    <!-- <script src="../aset/bootstrap/js/bootstrap.min.js"></script> -->