<?php include '../atribut/head.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
</head>

<header>
  <div class="overlay "></div>
  <div class="container h-100">
    <div class="d-flex h-100">
      <div class="w-100 text-black">

<div class="container">    
  <h2 class="text-center"><b>kostNING</b></h2>
  <br>
  <div class="row ">
    <div class="col-sm-6 bg-primary"><br>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.554386416908!2d112.6133003147791!3d-7.94151899427969!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78820b37b7d519%3A0xdc7e8db0a8bbebff!2sJl.+Kembang+Kertas+No.24%2C+Jatimulyo%2C+Kec.+Lowokwaru%2C+Kota+Malang%2C+Jawa+Timur+65141!5e0!3m2!1sid!2sid!4v1562677996171!5m2!1sid!2sid"  frameborder="0" style="border:0" allowfullscreen></iframe>
      <hr>jln. kembang kertas no 24 (depan toko sejahtera)<br><br>
    </div><br>

    <div class="col-sm-6">
      <div class="well well-sm text-center">
        <h4 class="bg-success fa fa-male"><b>Kost Putra</b></h4>
      </div>
      <div class="well">
        <p>Contact US </p><hr>
        <div class="row"><div class="col-xs-4">Telp/WA</div><div class="col-xs-8">: 0812-5219-4102</div>
        </div>
        <div class="row"><div class="col-xs-4">Email</div><div class="col-xs-8">: kostning@gmail.com</div>
      </div>
    </div>
  </div>
</div><br><br>


      </div>
    </div>
  </div>
</header>



</body>
</html>

<?php include '../atribut/foot.php'; ?>